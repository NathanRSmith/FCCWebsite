<?php 
/* config.php */

/* Tucano Responsive Template */
/* autor: entiri s.r.o. */

/* Enter your e-mail address */
/* All messages from the website will be sent to this e-mail address. */

$email_address = 'jsnopko@gmail.com';
                                             
/* Location: php/config.php */
?>