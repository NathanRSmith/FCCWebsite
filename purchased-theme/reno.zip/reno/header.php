<?php
global $entiri_opt;
?>
<!DOCTYPE html>

<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<link href="<?php echo get_template_directory_uri(); ?>/img/favicon.png" rel="icon" type="image/png">

<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->

<!--[if IE 7]>
<link href="css/font-awesome/font-awesome-ie7.min.css" rel="stylesheet">
<![endif]-->

<!-- Internet Explorer condition - HTML5 shim, for IE6-8 support of HTML5 elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->   
<?php wp_head(); ?>

</head>       
<body <?php body_class(); ?>>
	
	<?php custom_style(); ?>

	<!-- Header -->	
	<header id="home">


	  <nav class="navbar navbar-fixed-top" role="navigation">
	    <div class="navbar-inner">
	    	<?php if($entiri_opt['show_info_bar'] == 1) { ?>
			  	  <div class="info-bar">
			  	  	<div class="container">

			  	  	  <div class="phone-email pull-left">
				  	  	  <?php
				  	  	  if($entiri_opt['info_bar_phone'] != '') {
				  	  	  	echo '<i class="fa fa-phone"></i> '.$entiri_opt['info_bar_phone'].'&nbsp;&nbsp;&nbsp;&nbsp;';
				  	  	  }
				  	  	  if($entiri_opt['info_bar_email'] != '') {
				  	  	  	echo '<i class="fa fa-envelope"></i> <a href="'.$entiri_opt['info_bar_email'].'">'.$entiri_opt['info_bar_email'].'</a> &nbsp;&nbsp;&nbsp;&nbsp;';
				  	  	  }
				  	  	  ?>
			  	  	  </div>
				  	  <div class="pull-right">	  
				  	  	  <?php
				  	  	  if($entiri_opt['show_info_bar_social_icons'] == 1) {
				  	  	  	  echo '&nbsp;'.header_social_icons_display();
				  	  	  }
				  	  	  if($entiri_opt['show_info_bar_cart'] == 1) {
				  	  	  	  include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
				  	  	  	  if (is_plugin_active('woocommerce/woocommerce.php')) {

						     	  echo ' ';
						     	  woocommerce_header_cart();

						      }
				  	  	  	  
				  	  	  }
				  	  	  if($entiri_opt['show_info_bar_account_link'] == 1) { ?>

				  	  	  	  | <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php _e('Login', 'reno'); ?></a>
				  	  	  	  <?php
				  	  	  }
				  	  	  
				  	  	  ?>
				  	  	</div>
			  	  	</div>
			  	  </div>
			  	  <div class="cleaner"></div>
			  	  <?php //woocommerce_myaccount_page_id ?>
			  <?php } ?>
			<div class="container">
				
  	    <!-- logo with back to top -->  
				<?php
				if(isset($entiri_opt['logo'])) {
					$logo_url = $entiri_opt['logo']['url'];
				}
				else {
					$logo_url = get_template_directory_uri().'/img/logo.png';
				}
				?>
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="Home" class="">
					<img src="<?php echo $logo_url; ?>" class="logo">
				</a>  

	            <!-- Menu -->
	            <?php wp_nav_menu( array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'nav navbar-nav') ); ?> 
	            <!-- Menu End -->           					
			</div>
	    </div>
		</nav>
	</header>


	<!-- Content -->
	
	<section id="section">
		