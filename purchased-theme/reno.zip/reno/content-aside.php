<?php
/**
 * The default template for displaying content. Used for both single and index/archive/search.
 */
?>

	<div class="row">
		<div class="span1">
  
          <div class="blog-icon">
            <i class="icon-quote-right"></i><br>
            <h5><?php _e( 'Single post', 'reno' ); ?></h5>                  
          </div>
             
        </div>
        <div class="span8">
			<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
			<div class="featured-post">
				<?php _e( 'Featured post', 'reno' ); ?>
			</div>
			<?php endif; ?>
			
			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('listing'); ?></a>
			<div class="post-d-info">
				<?php if ( is_single() ) : ?>
				<h3 class="entry-title"><?php the_title(); ?></h3>
				<?php else : ?>
				
				<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( __( 'Permalink to %s', 'reno' ), the_title_attribute( 'echo=0' ) ) ); ?>" rel="bookmark"><h3><?php the_title(); ?></h3></a>
				
				<?php endif; // is_single() ?>
				
				

				<footer class="entry-meta">
					<div class="blue-dark">
                    <i class="icon-user"></i> By <?php echo get_the_author(); ?> <i class="icon-tag"></i> <?php the_tags('',' | ',''); ?> <i class="icon-comment-alt"></i> <?php comments_number(); ?> 
                    </div>
				</footer><!-- .entry-meta -->
				<?php if (get_option('reno_disable_autop') == 'true') echo '<p>'; ?>
				<?php if ( is_search() ) : // Only display Excerpts for Search ?>
				<div class="entry-summary">
					<?php the_excerpt(); ?>
				</div><!-- .entry-summary -->
				<?php else : ?>
				<div class="entry-content">
					<?php the_content( __( 'Continue reading <span class="meta-nav">&rarr;</span>', 'reno' ) ); ?>
					<?php wp_link_pages( array( 'before' => '<div class="page-links">' . __( 'Pages:', 'reno' ), 'after' => '</div>' ) ); ?>
				</div><!-- .entry-content -->
				<?php endif; ?>
				<?php if (get_option('reno_disable_autop') == 'true') echo '</p>'; ?>
			</div><!-- .post-d-info -->
			<?php if ( is_single() ) : ?>
			<?php comments_template( '', true ); ?>
			<?php endif; // is_single() ?>
		</div><!-- .span8 -->
	</div><!-- .row -->
