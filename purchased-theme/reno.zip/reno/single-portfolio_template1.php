 <div class="row">
  <div class="span8">
    <h2><?php the_title(); ?></h2>      
  </div>
  <div class="span4">
    <!--breadcrumb -->      
  </div>      
</div>    

<div class="row">
  <div class="span6">
    <div id="slider-nivo" class="nivoSlider bottom">
        <?php echo reno_get_gallery(get_post_meta($post->ID, 'reno_portfolio_gallery', true), 'portfolio_medium'); ?>
    </div>    
    
  </div>
  <div class="span6">
    <div class="project-heading">
      <div class="project-title"><h1><?php the_title(); ?></h1></div>
      <div class="project-all">
        <?php next_post_link('%link', '<i class="icon-angle-right"></i>'); ?>
        
        <a href="<?php echo get_option('reno_projects_url'); ?>" data-placement="top" data-toggle="tooltip" title="" data-original-title="all"><i class="icon-th"></i> </a>
        
        <?php previous_post_link('%link', '<i class="icon-angle-left"></i>'); ?>
      </div>        
    </div>
    <h5><?php echo get_post_meta($post->ID, 'reno_portfolio_type', true); ?></h5>
    <?php the_content(); ?>
    <?php if(get_post_meta($post->ID, 'reno_portfolio_link', true) != '') { ?>
      <a class="btn btn-color-2 btn-large pull-right" href="<?php echo get_post_meta($post->ID, 'reno_portfolio_link', true); ?>" rel="external"><i class="icon-spinner icon-spin"></i> Project completed</a>
    <?php } ?>
  </div>
</div>



            
