<form role="search" method="get" id="searchform" class="shop-search" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
	
		
		<input type="text" name="s" placeholder="Search"><button class="search-icon" type="submit"><i class="icon-search"></i> </button>
		<input type="hidden" name="post_type" value="product" />
	
</form>