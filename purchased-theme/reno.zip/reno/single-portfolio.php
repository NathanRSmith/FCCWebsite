<?php
global $entiri_opt;
/**
 * The Template for displaying all single posts.
 */

get_header(); ?>

	

			<?php while ( have_posts() ) : the_post(); ?>

				<?php if(get_post_meta($post->ID,'show_heading',true) == 'yes' || get_post_meta($post->ID,'show_breadcrumb',true) == 'yes') { ?>
					<div class="row spacer40"></div>
				<?php } ?>
				<div class="container">
					<div class="row">
					<?php if(get_post_meta($post->ID,'show_heading',true) == 'yes') { ?>
						<div class="col-md-8">
							<h3 class="site-title"><?php the_title(); ?></h3>
							<div class="row spacer20"></div>
							
						</div>
						<div class="col-md-4">
							<?php if(get_post_meta($post->ID,'show_breadcrumb',true) == 'yes') { ?>
								<?php if(function_exists('bcn_display'))
							    {
							    	echo '<ul class="breadcrumb">';
							        bcn_display();
							        echo '</ul>';
							    }?>
							<?php } ?>
						</div>
					<?php } ?>
					</div>
				</div>
					<?php

					if(get_post_meta($post->ID, 'reno_portfolio_template', true) == 'full-width' || get_post_meta($post->ID, 'reno_portfolio_template', true) == '') {
						load_template(TEMPLATEPATH . '/portfolio-full.php');
					}
					if(get_post_meta($post->ID, 'reno_portfolio_template', true) == 'left-sidebar') {
						load_template(TEMPLATEPATH . '/portfolio-left-sidebar.php');
					}
					if(get_post_meta($post->ID, 'reno_portfolio_template', true) == 'right-sidebar') {
						load_template(TEMPLATEPATH . '/portfolio-right-sidebar.php');
					}
					if(get_post_meta($post->ID, 'show_related_posts', true) == 'yes') {
					?>

						<div class="container">
							<div class="row">
						      <div class="col-md-12">
						      <h4><?php _e('Related projects', 'reno'); ?></h4>             
						        <div class="owl-carousel carousel-top-navigation">           
						          	<?php
						          	$loop = new WP_Query( array( 'post_type' => 'portfolio', 'posts_per_page' => 8 ) );
								  	while ( $loop->have_posts() ) : $loop->the_post();
							          	$id_post = $loop->post->ID;
							          	$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($id_post), 'recent-news' );
							    		$full = wp_get_attachment_image_src( get_post_thumbnail_id($id_post), 'lightbox' );
							    		?>
								          <div class="item"> 
								            <div class="project-item">
								              <div class="project-image">
								                <img src="<?php echo $thumb[0]; ?>" alt="sdf">
								                <span class="divider"></span>
								                  <a href="<?php echo $full[0]; ?>" class="media-link-1 popup-link" title=""><?php _e('SHOW', 'reno'); ?></a>
								                  <a class="media-link-2" href="<?php the_permalink(); ?>"><?php _e('DETAIL', 'reno'); ?></a>                            
								              </div>
								              <div class="project-text">
								              <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
								              <?php echo get_post_meta($id_post, 'reno_portfolio_excerpt', true); ?>
								              </div>              
								            </div>              
								          </div>         
								        <?php
								    endwhile;
								    wp_reset_query();
						            ?>     

						        </div>      
						      </div>
						    </div>

						    <div class="row spacer60"></div>
						</div>
						
					<?php } ?>

			<?php endwhile; // end of the loop. ?>
		
	


<?php get_footer(); ?>