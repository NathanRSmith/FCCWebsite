<?php
global $entiri_opt;
?>
<div class="container">
	<div class="row">
		
		<div class="col-md-9">

			<?php the_content(); ?>
		</div>
		<div class="col-md-3 sidebar">
			<?php get_sidebar(); ?>
		</div>
	</div>
</div>

<div class="row spacer80"></div>

				
				